import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Logout from './components/Logout';
import PrivateRoute from './components/PrivateRoute';
import AdminDashboard from './components/AdminDashboard';
import ManagerDashboard from './components/ManagerDashboard';
import StudentDashboard from './components/StudentDashboard';
import AdminSubmissions from './components/AdminSubmissions';
import StudentForm from './components/StudentForm';  // Import the StudentForm component
import Navbar from './components/Navbar.js';
import Unauthorized from './components/Unauthorized'; // Create this component for unauthorized access
import ManagerComponent from './components/ManagerComponent.js'; // Make sure this is the correct path
import StudentList from './components/StudentList'; // Import the StudentList component
import MStudentList from './components/ManagerStudentList.js';
import MStudentsubmission from './components/ManagerSubmission.js';
function App() {
  return (
    <Router>
      <Routes>
        {/* Login and Logout */}
        <Route path="/login" element={<Login />} />
        <Route path="/logout" element={<Logout />} />

        {/* Admin dashboard protected by role */}
        <Route 
          path="/admin-dashboard" 
          element={
            <PrivateRoute role="admin">
              <Navbar /> 
              <AdminDashboard />
            </PrivateRoute>
          } 
        />

        {/* Admin view submissions route */}
        <Route 
          path="/admin/view-submissions" 
          element={
            <PrivateRoute role="admin">
              <Navbar /> 
              <AdminSubmissions />
            </PrivateRoute>
          } 
        />

        {/* Manager dashboard protected by role */}
        <Route 
          path="/manager-dashboard" 
          element={
            <PrivateRoute role="manager">
              <Navbar /> 
              <ManagerDashboard />
            </PrivateRoute>
          } 
        />
 {/* ManagerComponent route */}
 <Route 
 
          path="/manager" 
          element={<ManagerComponent />} 
        />
 {/* Route for Student List */}
 <Route path="/student-list" element={<StudentList />} />
 <Route path="/managerstudent-list" element={<MStudentList />} />
 <Route path="/manager/view-submissions" element={<MStudentsubmission />} />

        {/* Student dashboard protected by role */}
        <Route 
          path="/student-dashboard" 
          element={
            <PrivateRoute role="student">
              <Navbar />
              <StudentDashboard />
            </PrivateRoute>
          } 
        />

        {/* Route for Public Student Form Submission */}
        <Route 
          path="/student-form" 
          element={<StudentForm />}  // Public route for student form submission
        />

        {/* Unauthorized route */}
        <Route path="/unauthorized" element={<Unauthorized />} />

        {/* Default route for "/" */}
        <Route path="/" element={<Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;
