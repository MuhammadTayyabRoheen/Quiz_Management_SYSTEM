import api from '../api';
import jwt_decode from 'jwt-decode';  // Correct import

const AuthService = {
  login: async (credentials) => {
    const response = await api.post('/login', credentials);
    const { token } = response.data.data;
    localStorage.setItem('token', token);
    return jwt_decode(token);  // Correct function usage
  },

  logout: () => {
    localStorage.removeItem('token');
  },

  getCurrentUser: () => {
    const token = localStorage.getItem('token');
    return token ? jwt_decode(token) : null;  // Correct function usage
  },

  isAuthenticated: () => {
    return !!localStorage.getItem('token');
  }
};

export default AuthService;
