import React, { useState, useEffect } from 'react';
import api from '../api'; // Axios instance that includes the authorization token
import '../styles/AdminSubmissions.css'; // Link to the CSS file

const AdminSubmissions = () => {
  const [submissions, setSubmissions] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [loading, setLoading] = useState(false);  // Loading state

  useEffect(() => {
    fetchSubmissions();
  }, []);

  const fetchSubmissions = async () => {
    setLoading(true);
    try {
      const response = await api.get('/admin/show-students');
      setSubmissions(response.data.data || []);
      setLoading(false);
    } catch (error) {
      setErrorMessage('Failed to fetch submissions.');
      setLoading(false);
    }
  };

  const handleAccept = async (id) => {
    try {
      await api.post(`/admin/approve-student/${id}`);
      fetchSubmissions(); // Refresh the list after approving
      alert('Student submission accepted.');
    } catch (error) {
      setErrorMessage('Failed to accept student submission.');
    }
  };

  const handleReject = async (id) => {
    try {
      await api.post(`/admin/reject-student/${id}`);
      fetchSubmissions(); // Refresh the list after rejecting
      alert('Student submission rejected.');
    } catch (error) {
      setErrorMessage('Failed to reject student submission.');
    }
  };

  return (
    <div className="admin-submissions-container">
      <h2 className="title">Student Submissions</h2>

      {/* Error and Loading Messages */}
      {loading && <div className="loading">Loading submissions...</div>}
      {errorMessage && <div className="error">{errorMessage}</div>}

      {/* Display submissions */}
      {submissions.length > 0 ? (
        <div className="submission-list">
          {submissions.map((submission) => (
            <div key={submission.id} className="submission-card">
              <p className="student-info">
                <strong>{submission.name}</strong> (<a href={`mailto:${submission.email}`}>{submission.email}</a>)
              </p>
              <p>
                <a href={`http://localhost:8000/storage/cv_files${submission.cv_path}`} target="_blank" rel="noopener noreferrer" className="view-cv">
                  View CV
                </a>
              </p>
              <p>Status: <span className={`status ${submission.status}`}>{submission.status}</span></p>

              {submission.status === 'pending' && (
                <div className="action-buttons">
                  <button onClick={() => handleAccept(submission.id)} className="btn-accept">Accept</button>
                  <button onClick={() => handleReject(submission.id)} className="btn-reject">Reject</button>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <p className="no-submissions">No submissions found</p>
      )}
    </div>
  );
};

export default AdminSubmissions;
