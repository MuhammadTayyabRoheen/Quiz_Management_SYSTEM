import React, { useState, useEffect } from 'react';
import api from '../api';  // Axios instance or API utility for calls
import { useNavigate } from 'react-router-dom';

const ManagerDashboard = () => {
  const [students, setStudents] = useState([]);  // To store student data
  const [quizzes, setQuizzes] = useState([]);    // To store quiz data
  const [selectedStudentId, setSelectedStudentId] = useState('');  // For quiz assignment
  const [selectedQuizId, setSelectedQuizId] = useState('');        // For quiz assignment
  const [loading, setLoading] = useState(true);   // Loading state
  const [errorMessage, setErrorMessage] = useState(''); // Error message
  const navigate = useNavigate();

  // Fetch all data on component mount
  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    try {
      await Promise.all([fetchStudents(), fetchQuizzes()]);
      setLoading(false); // After fetching all data, set loading to false
    } catch (error) {
      setErrorMessage('Failed to load data. Please try again later.');
      setLoading(false);
    }
  };

  // Fetch Students
  const fetchStudents = async () => {
    try {
      const response = await api.get('/manager/students');  // Correct API route
      setStudents(response.data.data || []); // Assuming data is in the "data" field
    } catch (error) {
      console.error('Failed to fetch students', error);
      setErrorMessage('Failed to fetch students.');
    }
  };

  // Fetch Quizzes
  const fetchQuizzes = async () => {
    try {
      const response = await api.get('/manager/quizzes');  // Correct API route
      setQuizzes(response.data.data || []); // Assuming data is in the "data" field
    } catch (error) {
      console.error('Failed to fetch quizzes', error);
      setErrorMessage('Failed to fetch quizzes.');
    }
  };

  // Assign quiz to student
  const handleAssignQuiz = async (e) => {
    e.preventDefault();
    if (!selectedStudentId || !selectedQuizId) {
      alert('Please select both a student and a quiz.');
      return;
    }

    const selectedQuiz = quizzes.find((quiz) => quiz.id === parseInt(selectedQuizId));
    if (!selectedQuiz) {
      alert('Selected quiz not found.');
      return;
    }

    try {
      await api.post(`/manager/assign-quiz/${selectedStudentId}`, {
        quizId: selectedQuizId,
        title: selectedQuiz.title,  // Use the quiz title
        description: selectedQuiz.description, // Use the quiz description
      });
      alert('Quiz assigned successfully');
    } catch (error) {
      console.error('Failed to assign quiz', error);
      setErrorMessage('Failed to assign quiz.');
    }
  };

  // Navigate to Student List page
  const goToStudentList = () => {
    navigate('/managerstudent-list'); // Navigate to the student list page
  };

  return (
    <div className="manager-dashboard-container">
      <h2 className="dashboard-title">Manager Dashboard</h2>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <>
          {errorMessage && <div className="error-message">{errorMessage}</div>}

          {/* Assign Quizzes */}
          <div className="assign-section">
            <h3>Assign Quiz to Student</h3>
            <form className="quiz-assign-form" onSubmit={handleAssignQuiz}>
              <select
                value={selectedStudentId}
                onChange={(e) => setSelectedStudentId(e.target.value)}
                className="select-field"
                required
              >
                <option value="">Select Student</option>
                {students.length > 0 ? (
                  students.map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.name}
                    </option>
                  ))
                ) : (
                  <option disabled>No students available</option>
                )}
              </select>

              <select
                value={selectedQuizId}
                onChange={(e) => setSelectedQuizId(e.target.value)}
                className="select-field"
                required
              >
                <option value="">Select Quiz</option>
                {quizzes.length > 0 ? (
                  quizzes.map((quiz) => (
                    <option key={quiz.id} value={quiz.id}>
                      {quiz.title}
                    </option>
                  ))
                ) : (
                  <option disabled>No quizzes available</option>
                )}
              </select>

              <button type="submit" className="submit-button">
                Assign Quiz
              </button>
            </form>
          </div>

          {/* View Quizzes */}
          <div className="quiz-section">
            <h3>View All Quizzes</h3>
            {quizzes.length > 0 ? (
              <ul>
                {quizzes.map((quiz) => (
                  <li key={quiz.id}>
                    {quiz.title} - {quiz.totalQuestions || 0} questions
                  </li>
                ))}
              </ul>
            ) : (
              <p>No quizzes found</p>
            )}
          </div>

          {/* Button to Show Student Section */}
          <button className="toggle-button" onClick={goToStudentList}>
            Show Student Section
          </button>
        </>
      )}
    </div>
  );
};

export default ManagerDashboard;
