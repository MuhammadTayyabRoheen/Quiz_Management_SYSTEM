import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';  // Axios instance
import './Login.css';  // Import the new CSS

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);  // New loading state
  const navigate = useNavigate(); 

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);  // Show loading

    try {
      const response = await api.post('/login', { email, password });
      const { token, role } = response.data.data;
      localStorage.setItem('token', token);
      localStorage.setItem('role', JSON.stringify(role));

      if (role.includes('admin')) {
        window.location.href = '/admin-dashboard';
      } else if (role.includes('manager')) {
        window.location.href = '/manager-dashboard';
      } else if (role.includes('student')) {
        window.location.href = '/student-dashboard';
      }
    } catch (err) {
      if (err.response && err.response.status === 401) {
        setError('Invalid email or password. Please try again.');
      } else {
        setError('An unexpected error occurred. Please try again later.');
      }
    } finally {
      setLoading(false);  // Hide loading spinner
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Login</h2>
        <form onSubmit={handleSubmit} className="login-form">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            required
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            required
          />
          {loading ? (
            <button type="submit" disabled>
              <span className="loading-spinner"></span> Logging In...
            </button>
          ) : (
            <button type="submit">Login</button>
          )}
        </form>

        {error && <p className="error-message">{error}</p>}

        <button 
          className="student-form-button"
          onClick={() => navigate('/student-form')}  
        >
          Submit Student Form
        </button>
      </div>
    </div>
  );
};

export default Login;
