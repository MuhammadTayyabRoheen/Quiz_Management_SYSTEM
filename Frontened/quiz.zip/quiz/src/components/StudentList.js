import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation
import api from '../api'; // Replace with your actual API path
import '../styles/StudentList.css'; // Correct path for the CSS file

const StudentList = () => {
  const [students, setStudents] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate(); // Declare useNavigate hook

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const response = await api.get('/admin/students');
      
      setStudents(response.data.data || []);
    } catch (error) {
      setErrorMessage('Failed to fetch students.');
    }
  };

  const goBackToDashboard = () => {
    navigate('/admin-dashboard'); // Navigate back to the admin dashboard
  };

  return (
    <div className="student-list-container">
      <h2 className="dashboard-title">Student List</h2>
      {errorMessage && <div className="error-message">{errorMessage}</div>}

      {/* Additional Content */}
      <div className="student-section">
        <h3 className="section-title">Manage Submissions</h3>
        <a href="/admin/view-submissions" className="link">View Student Submissions</a>
      </div>

      {/* Student Table */}
      <div className="student-table-wrapper">
        <table className="student-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <tr key={student.id}>
                <td>{student.name}</td>
                <td>{student.email}</td>
                <td>{student.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Back to Admin Dashboard Button */}
      <div className="back-button-container">
        <button className="back-button" onClick={goBackToDashboard}>Back to Admin Dashboard</button>
      </div>
    </div>
  );
};

export default StudentList;
