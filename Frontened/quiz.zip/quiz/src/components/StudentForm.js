// File: src/components/StudentForm.js

import React, { useState } from 'react';
import axios from 'axios';  // Import axios directly for custom calls

const StudentForm = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [cvFile, setCvFile] = useState(null); // To store file

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Create FormData object to handle the form submission with file
    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('cv_file', cvFile); // Append file to FormData

    try {
      // Use full URL to override the baseURL in axios instance
      await axios.post('http://localhost:8000/student/submit-form', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      // Show success message
      alert('Form submitted successfully');
    } catch (error) {
      // Handle any errors during the form submission
      console.error('Failed to submit form', error);
      alert('Error submitting form');
    }
  };

  return (
    <div>
      <h2>Student Form Submission</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Your Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="email"
          placeholder="Your Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="file"
          onChange={(e) => setCvFile(e.target.files[0])}
          required
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default StudentForm;
