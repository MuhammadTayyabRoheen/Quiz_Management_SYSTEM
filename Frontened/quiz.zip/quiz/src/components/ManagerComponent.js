import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate from react-router-dom
import api from '../api'; // Axios instance for API calls
import '../styles/ManagerComponent.css';

const ManagerComponent = () => {
  const navigate = useNavigate(); // Hook for navigation
  const [managers, setManagers] = useState([]);
  const [newManager, setNewManager] = useState({ name: '', email: '' });
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    fetchManagers();
  }, []);

  const fetchManagers = async () => {
    try {
      const response = await api.get('/admin/managers');
      setManagers(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error('Failed to fetch managers', error);
      setErrorMessage('Failed to fetch managers.');
    }
  };

  const handleAddManager = async (e) => {
    e.preventDefault();
    try {
      await api.post('/admin/add-manager', newManager);
      alert('Manager added successfully');
      fetchManagers();  // Refresh manager list
      setNewManager({ name: '', email: '' }); // Reset form
    } catch (error) {
      console.error('Failed to add manager', error);
      setErrorMessage('Failed to add manager.');
    }
  };

  const goBackToDashboard = () => {
    navigate('/admin-dashboard'); // Use navigate to go back to AdminDashboard
  };

  return (
    <div className="manager-component-container">
      <h2 className="dashboard-title">Manager Component</h2>

      {errorMessage && <div className="error-message">{errorMessage}</div>}

      <form onSubmit={handleAddManager}>
        <input
          type="text"
          placeholder="Manager Name"
          value={newManager.name}
          onChange={(e) => setNewManager({ ...newManager, name: e.target.value })}
          required
        />
        <input
          type="email"
          placeholder="Manager Email"
          value={newManager.email}
          onChange={(e) => setNewManager({ ...newManager, email: e.target.value })}
          required
        />
        <button type="submit">Add Manager</button>
      </form>

      <h4>Manager List</h4>
      <ul>
        {managers.map((manager) => (
          <li key={manager.id}>{manager.name} - {manager.email}</li>
        ))}
      </ul>

      {/* Back button to go back to AdminDashboard */}
      <button onClick={goBackToDashboard} className="back-button">Back to Admin Dashboard</button>
    </div>
  );
};

export default ManagerComponent;
