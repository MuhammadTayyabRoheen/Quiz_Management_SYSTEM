import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../styles/Navbar.css';

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <nav className="navbar">
      <div className="logo">My Dashboard</div>
      <ul className="nav-links">
        <li><Link to="/admin-dashboard">Dashboard</Link></li>
        <li><Link to="/submissions">Submissions</Link></li>
      </ul>

      <button className="logout-button" onClick={() => {
        window.location.href = '/login';
      }}>Logout</button>

      <div className="mobile-menu-icon" onClick={toggleMobileMenu}>
        <i className="fas fa-bars"></i> {/* FontAwesome icon */}
      </div>

      <ul className={`nav-links-mobile ${mobileMenuOpen ? 'show-mobile-menu' : ''}`}>
        <li><Link to="/admin-dashboard" onClick={toggleMobileMenu}>Dashboard</Link></li>
        <li><Link to="/submissions" onClick={toggleMobileMenu}>Submissions</Link></li>
        <li><button className="logout-button" onClick={() => {
          window.location.href = '/login';
        }}>Logout</button></li>
      </ul>
    </nav>
  );
};

export default Navbar;
