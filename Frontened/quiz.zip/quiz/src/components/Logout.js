import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';  // To navigate between routes
import api from '../api';  // Axios instance

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();  // Hook to navigate to another route

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Make POST request to the Laravel API
      const response = await api.post('/login', { email, password });

      // Extract token, user, and role from the response
      const { token, role } = response.data.data;

      // Save token and role in localStorage for future requests
      localStorage.setItem('token', token);
      localStorage.setItem('role', JSON.stringify(role));  // Save role array as a JSON string

      // Redirect based on the user's role
      if (role.includes('admin')) {
        window.location.href = '/admin-dashboard';
      } else if (role.includes('manager')) {
        window.location.href = '/manager-dashboard';
      } else if (role.includes('student')) {
        window.location.href = '/student-dashboard';
      }
    } catch (err) {
      // Handle error and display message to the user
      if (err.response && err.response.status === 401) {
        setError('Invalid email or password. Please try again.');
      } else {
        setError('An unexpected error occurred. Please try again later.');
      }
      console.error("Login error:", err.response ? err.response.data : err);
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          required
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          required
        />
        <button type="submit">Login</button>
      </form>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {/* New Button for Public Student Form Submission */}
      <button 
        onClick={() => navigate('/student-form')}  // Navigate to the student form page
        style={{ marginTop: '20px', display: 'block' }}
      >
        Submit Student Form
      </button>
    </div>
  );
};

export default Login;
