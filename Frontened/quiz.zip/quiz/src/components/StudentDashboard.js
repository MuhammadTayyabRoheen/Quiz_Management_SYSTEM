import { useState, useEffect, useRef } from 'react';
import api from '../api'; // Axios instance for API calls
import '../styles/StudentDashboard.css';

const StudentDashboard = () => {
  const [assignedQuizzes, setAssignedQuizzes] = useState([]);
  const [attemptedQuizzes, setAttemptedQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [quizResults, setQuizResults] = useState(null);
  const [answers, setAnswers] = useState({}); // To store the selected answers
  const [quizQuestions, setQuizQuestions] = useState([]); // To store the quiz questions
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0); // Track current question
  const [isRecording, setIsRecording] = useState(false); // To track recording status

  const videoRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const recordedChunks = useRef([]);

  useEffect(() => {
    fetchQuizzes();
  }, []);

  // Fetch quizzes assigned to the student
  const fetchQuizzes = async () => {
    try {
      const response = await api.get('/student/quizzes');
      if (response.data && response.data.data) {
        const { assignedQuizzes, attemptedQuizzes } = response.data.data;
        setAssignedQuizzes(assignedQuizzes || []);
        setAttemptedQuizzes(attemptedQuizzes || []);
      }
      setLoading(false);
    } catch (error) {
      setErrorMessage('Failed to load quizzes');
      setLoading(false);
    }
  };

  // Function to start video recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      videoRef.current.srcObject = stream;

      const options = { mimeType: 'video/webm; codecs=vp9' };
      const mediaRecorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunks.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunks.current, { type: 'video/webm' });
        const videoUrl = URL.createObjectURL(blob);
        downloadRecordedVideo(videoUrl); // Optionally save the video
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error('Error accessing media devices:', err);
      setErrorMessage('Failed to access camera and microphone.');
    }
  };

  // Function to stop video recording
  const stopRecording = () => {
    mediaRecorderRef.current.stop();
    const tracks = videoRef.current.srcObject.getTracks();
    tracks.forEach(track => track.stop());
    setIsRecording(false);
  };

  // Function to download the recorded video
  const downloadRecordedVideo = (videoUrl) => {
    const a = document.createElement('a');
    document.body.appendChild(a);
    a.style = 'display: none';
    a.href = videoUrl;
    a.download = 'quiz_attempt.webm';
    a.click();
    window.URL.revokeObjectURL(videoUrl);
  };

  // Move to the next question
  const goToNextQuestion = () => {
    setCurrentQuestionIndex(currentQuestionIndex + 1);
  };

  const startQuiz = async (quizId) => {
    try {
      console.log(`Starting quiz with ID: ${quizId}`);
      const response = await api.post(`/student/quiz/${quizId}/start`);
      console.log('Quiz start response:', response.data);

      if (response.data && response.data.data) {
        setSelectedQuiz(response.data.data); // Store full quiz data
        await fetchQuizQuestions(quizId); // Fetch questions
        startRecording(); // Start video recording
      } else {
        setErrorMessage('No quiz data found');
      }
    } catch (error) {
      console.error('Error starting quiz:', error);
      setErrorMessage('Failed to start quiz');
    }
  };

  const fetchQuizQuestions = async (quizId) => {
    try {
      console.log("Fetching quiz questions for quiz ID:", quizId);
      const response = await api.get(`/student/quiz/${quizId}/questions`);
      console.log("Quiz questions fetched:", response.data);
      if (response.data && response.data.data && response.data.data.questions) {
        setQuizQuestions(response.data.data.questions);
        setErrorMessage('');
      } else {
        setErrorMessage('No questions found for this quiz');
      }
    } catch (error) {
      console.error("Error fetching quiz questions:", error);
      setErrorMessage('Failed to fetch quiz questions');
    }
  };

  // Handle answer selection
  const handleAnswerChange = (questionId, selectedOption) => {
    setAnswers((prevAnswers) => ({
      ...prevAnswers,
      [questionId]: selectedOption,
    }));
  };
  const submitQuiz = async () => {
    if (!selectedQuiz || !selectedQuiz.id) {
      setErrorMessage('No quiz selected');
      return;
    }
  
    // Stop the video recording before submitting the quiz
    stopRecording();
  
    try {
      const formData = new FormData();
  
      // Correctly append answers as array in FormData
      Object.keys(answers).forEach((questionId, index) => {
        formData.append(`answers[${index}][question_id]`, questionId);
        formData.append(`answers[${index}][answer]`, answers[questionId]);
      });
  
      // Append the quiz ID
      formData.append('quiz_id', selectedQuiz.id);
  
      // If there's a video, append it
      if (recordedChunks.current.length > 0) {
        const blob = new Blob(recordedChunks.current, { type: 'video/webm' });
        formData.append('video', blob, 'quiz_attempt.webm');
      }
  
      // Send the request to the backend
      const response = await api.post(`/student/attempt-quiz/${selectedQuiz.id}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
  
      // Handle the response from the backend
      if (response.data.success) {
        const { score, results } = response.data.data;
        setQuizResults({ score, results });
      }
  
    } catch (error) {
      console.error('Error submitting quiz:', error);
      setErrorMessage('Failed to submit quiz');
    }
  };
  
  
  // Fetch quiz results when "View Results" is clicked
  const fetchQuizResults = async (quizId) => {
    try {
      console.log("Fetching quiz results for quiz ID:", quizId); // Debugging log
      const response = await api.get(`/student/quiz-results/${quizId}`);
      console.log("Quiz results fetched:", response.data); // Debugging log
      if (response.data && response.data.data) {
        setQuizResults(response.data.data); // Set the quiz results to state
        setErrorMessage('');
      } else {
        setErrorMessage('No results available for this quiz.');
      }
    } catch (error) {
      console.error("Error fetching quiz results:", error); // Debugging log
      if (error.response && error.response.status === 404) {
        setErrorMessage('No results found for this quiz.');
      } else {
        setErrorMessage('Failed to fetch quiz results');
      }
    }
  };

  const currentQuestion = quizQuestions[currentQuestionIndex];

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div className="student-dashboard">
      <h1>Student Dashboard</h1>

      {/* Display error messages if any */}
      {errorMessage && <p className="error">{errorMessage}</p>}

      {/* Assigned Quizzes Section */}
      <h2>Assigned Quizzes</h2>
      {assignedQuizzes.length === 0 ? (
        <p>No assigned quizzes available.</p>
      ) : (
        <ul>
          {assignedQuizzes.map((quiz) => (
            <li key={quiz.id}>
              {quiz.title} - {quiz.description}
              <button onClick={() => startQuiz(quiz.id)}>Start Quiz</button>
            </li>
          ))}
        </ul>
      )}

      {/* Attempted Quizzes Section */}
      <h2>Attempted Quizzes</h2>
      {attemptedQuizzes.length === 0 ? (
        <p>No attempted quizzes yet.</p>
      ) : (
        <ul>
          {attemptedQuizzes.map((quiz) => (
            <li key={quiz.id}>
              {quiz.quiz.title} - {quiz.quiz.description}
              <button onClick={() => fetchQuizResults(quiz.quiz_id)}>View Results</button>
            </li>
          ))}
        </ul>
      )}

      {/* Display quiz questions after quiz is started */}
      {selectedQuiz && quizQuestions.length > 0 && (
        <div className="quiz-container">
          <h3>Quiz: {selectedQuiz.title}</h3>

          {/* Display current question */}
          <div>
            <p>{currentQuestion.question_text}</p>
            <ul>
              {currentQuestion.options.map((option, idx) => (
                <li key={idx}>
                  <input
                    type="radio"
                    name={currentQuestion.id}
                    value={option}
                    onChange={() => handleAnswerChange(currentQuestion.id, option)}
                  />
                  {option}
                </li>
              ))}
            </ul>
          </div>

          {/* Next button or Submit button */}
          {currentQuestionIndex < quizQuestions.length - 1 ? (
            <button onClick={goToNextQuestion}>Next</button>
          ) : (
            <button onClick={submitQuiz}>Submit Quiz</button>
          )}

          {/* Video stream */}
          <div>
            <video ref={videoRef} autoPlay muted style={{ width: '300px', marginTop: '20px' }}></video>
          </div>
        </div>
      )}

      {/* Display quiz results after submission */}
      {quizResults && (
  <div>
    <h3>Quiz Results</h3>
    <p>Score: {quizResults.score}</p>

    {Array.isArray(quizResults.results) && quizResults.results.length > 0 ? (
      <ul>
        {quizResults.results.map((result, index) => (
          <li key={index}>
            Question {result.question_id}: {result.submitted_answer} - {result.is_correct ? 'Correct' : 'Incorrect'}
            {result.correct_answer && (
              <span> (Correct Answer: {result.correct_answer})</span>
            )}
          </li>
        ))}
      </ul>
    ) : (
      <p>No results available.</p>
    )}
  </div>
      )}
    </div>
  );
};

export default StudentDashboard;
