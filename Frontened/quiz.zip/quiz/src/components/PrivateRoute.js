import React from 'react';
import { Navigate } from 'react-router-dom';

const PrivateRoute = ({ children, role }) => {
  const token = localStorage.getItem('token');
  const userRole = JSON.parse(localStorage.getItem('role')); // Assuming you save role in localStorage

  // Check if token exists and role is valid
  if (!token || !userRole || !userRole.includes(role)) {
    return <Navigate to="/login" />;
  }

  return children;
};

export default PrivateRoute;
