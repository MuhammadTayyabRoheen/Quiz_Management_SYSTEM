import React, { useState, useEffect } from 'react';
import api from '../api';  
import { useNavigate } from 'react-router-dom';
import ManagerComponent from './ManagerComponent';

import '../styles/AdminDashboard.css';

const AdminDashboard = () => {
  // State to manage data
  const navigate = useNavigate();

  const [showQuizAssign, setShowQuizAssign] = useState(false);
  const [showManager, setShowManager] = useState(false);  // State to toggle ManagerComponent visibility

  const [students, setStudents] = useState([]);  // To store student data
  const [managers, setManagers] = useState([]);  // To store manager data
  const [quizzes, setQuizzes] = useState([]);    // To store quiz data
  const [quizDetails, setQuizDetails] = useState(null);  // Store quiz details for view
  const [questionText, setQuestionText] = useState(''); // Question input
  const [correctAnswer, setCorrectAnswer] = useState(''); // Correct answer input
  const [options, setOptions] = useState(['']); // Options for questions

 // Form states
 const [filterStatus, setFilterStatus] = useState(''); // To filter students by status
 const [selectedStudentId, setSelectedStudentId] = useState('');  // For quiz assignment
 const [selectedQuizId, setSelectedQuizId] = useState('');        // For quiz assignment
 const [newManager, setNewManager] = useState({ name: '', email: '' });  // Manager creation form

 // Miscellaneous states
 const [loading, setLoading] = useState(false);  // For showing loading state
 const [errorMessage, setErrorMessage] = useState('');  // For erro error handling

  // Fetch all data on component mount
  useEffect(() => {
    fetchAllData();
    fetchQuizzes();
  }, []);
// Show the quiz assign section when a button is clicked
const scrollToQuizAssignment = () => {
    const quizSection = document.querySelector(".quiz-assign-section");
    if (quizSection) {
      quizSection.scrollIntoView({ behavior: "smooth" });
      setShowQuizAssign(true); // Add the show class when the section becomes visible
    }
  };
  const toggleManagerComponent = () => {
    setShowManager(!showManager);
  };
  // Function to fetch all data
  const fetchAllData = async () => {
    setLoading(true);
    try {
      await Promise.all([fetchStudents(), fetchManagers(), fetchQuizzes()]);
    } catch (error) {
      setErrorMessage('Failed to load data. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  // Fetch Students
  const fetchStudents = async () => {
    try {
        const response = await api.get('/admin/students');
      setStudents(response.data.data || []);  // Assuming data is in the "data" field
    } catch (error) {
      console.error('Failed to fetch students', error);
      setErrorMessage('Failed to fetch students.');
    }
  };


  // Soft delete a student (remove from frontend, soft delete in backend)
  const handleDeleteStudent = async (id) => {
    try {
      // Soft delete student in the backend
      await api.delete(`/admin/students/${id}`);
      
      // Soft delete on the frontend (remove from the displayed list)
      setStudents((prevStudents) => prevStudents.filter(student => student.id !== id));
      
      alert('Student deleted successfully (soft deleted).');
    } catch (error) {
      console.error('Failed to delete student', error);
      setErrorMessage('Failed to delete student.');
    }
  };
  // Fetch Managers
  const fetchManagers = async () => {
    try {
      const response = await api.get('/admin/managers');
      setManagers(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      console.error('Failed to fetch managers', error);
      setErrorMessage('Failed to fetch managers.');
    }
  };
// Fetch Quizzes - Updated to fetch quiz list and details dynamically
const fetchQuizzes = async () => {
    try {
      const response = await api.get('/admin/quizzes'); // Fetching quizzes from the backend
      const quizList = response.data.data; // Ensure that this matches your backend response structure
      setQuizzes(quizList); // Set the quizzes in the state
    } catch (error) {
      console.error('Failed to fetch quizzes', error);
      setErrorMessage('Failed to fetch quizzes.');
    }
  };
  
  const fetchQuizDetails = async (quizId) => {
    console.log("Fetching quiz details for Quiz ID:", quizId);
    try {
        const response = await api.get(`/admin/quiz/${quizId}/details`);
        console.log("Quiz details fetched:", response.data);

        const fetchedQuizDetails = response.data.data || null;

        // Handle cases where questions are not available
        if (fetchedQuizDetails && !fetchedQuizDetails.questions) {
            fetchedQuizDetails.questions = [];
        }

        setQuizDetails(fetchedQuizDetails);
    } catch (error) {
        console.error('Failed to fetch quiz details', error);
        setErrorMessage('Failed to fetch quiz details.');
    }
};

  

  // Add Manager
  const handleAddManager = async (e) => {
    e.preventDefault();
    try {
      await api.post('/admin/add-manager', newManager);
      alert('Manager added successfully');
      fetchManagers();  // Refresh manager list
      setNewManager({ name: '', email: '' }); // Reset form
    } catch (error) {
      console.error('Failed to add manager', error);
      setErrorMessage('Failed to add manager.');
    }
  };

  // Accept Student
  const handleAcceptStudent = async (id) => {
    try {
      await api.post(`/admin/accept-student/${id}`);
      fetchStudents();  // Refresh student list
    } catch (error) {
      console.error('Failed to accept student', error);
      setErrorMessage('Failed to accept student.');
    }
  };

  // Reject Student
  const handleRejectStudent = async (id) => {
    try {
      await api.post(`/admin/reject-student/${id}`);
      fetchStudents();  // Refresh student list
    } catch (error) {
      console.error('Failed to reject student', error);
      setErrorMessage('Failed to reject student.');
    }
  };

  const handleAssignQuiz = async (e) => {
    e.preventDefault();
  
    console.log("Selected Student ID:", selectedStudentId);
    console.log("Selected Quiz ID:", selectedQuizId);
  
    if (!selectedStudentId || !selectedQuizId) {
      alert('Please select both a student and a quiz.');
      return;
    }
  
    // Find the selected quiz by its ID
    const selectedQuiz = quizzes.find(quiz => quiz.id === parseInt(selectedQuizId));
  
    // Check if the selected quiz exists
    if (!selectedQuiz) {
      alert('Selected quiz not found.');
      return;
    }
  
    try {
      await api.post(`/admin/assign-quiz/${selectedStudentId}`, {
        quizId: selectedQuizId,
        title: selectedQuiz.title,         // Use the quiz title
        description: selectedQuiz.description // Use the quiz description
      });
      alert('Quiz assigned successfully');
    } catch (error) {
      console.error('Failed to assign quiz', error);
      setErrorMessage('Failed to assign quiz.');
    }
  };
  
  
  
// Add Question to Quiz
const handleAddQuestion = async (quizId) => {
    if (!questionText || !correctAnswer || options.length === 0) {
        alert('Please fill in all fields');
        return;
    }

    try {
        const response = await api.post(`/admin/add-question/${quizId}`, {
            question_text: questionText,
            correct_answer: correctAnswer,
            options,
        });

        alert('Question added successfully');
        setQuestionText('');
        setCorrectAnswer('');
        setOptions(['']);
        // Optionally fetch quiz details again to update the list of questions
        fetchQuizDetails(quizId);
    } catch (error) {
        console.error('Failed to add question', error);
        setErrorMessage('Failed to add question.');
    }
};

  const handleOptionChange = (index, value) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };



  const goToManagerComponent = () => {
    navigate('/manager'); // Assuming you have a route '/manager' for ManagerComponent
  };

  const goToStudentList = () => {
    navigate('/student-list'); // Navigate to the student list page
  };

  // Filter students based on status
  const filteredStudents = filterStatus
    ? students.filter((student) => student.status === filterStatus)
    : students;
return (

    <div>
        
    <div className="admin-dashboard-container">
            
      <h2 className="dashboard-title">Admin Dashboard</h2>

      {loading && <div className="loading">Loading...</div>}

      {errorMessage && <div className="error-message">{errorMessage}</div>}
  {/* Button to go to the ManagerComponent */}
  <button className="toggle-button" onClick={goToManagerComponent}>
        Show Manager Section
      </button>
      {/* Conditionally render the ManagerComponent */}
      {showManager && <ManagerComponent />}

     {/* Button to navigate to Student List */}
     <button className="toggle-button" onClick={goToStudentList}>
        Show Student Section
      </button>
      
      <div className="quiz-section">
        <h3 className="section-title">View All Quizzes</h3>
        <ul className="list-group">
          {quizzes.length > 0 ? (
            quizzes.map((quiz) => (
              <li key={quiz.id} className="list-item">
                {quiz.title} - {quiz.totalQuestions || 0} questions
              </li>
            ))
          ) : (
            <li className="list-item">No quizzes found</li>
          )}
        </ul>
      </div>
      <button onClick={scrollToQuizAssignment} className="submit-button">
        Go to Assign Quiz
      </button>
      <section className={`quiz-assign-section ${showQuizAssign ? 'show' : ''}`}>        <h3 className="section-title">Assign Quiz to Student</h3>
        <form className="quiz-assign-form" onSubmit={handleAssignQuiz}>
          <select
            value={selectedStudentId}
            onChange={(e) => setSelectedStudentId(e.target.value)}
            className="select-field"
            required
          >
            <option value="">Select Student</option>
            {students.length > 0 && students.map((student) => (
              <option key={student.id} value={student.id}>
                {student.name}
              </option>
            ))}
          </select>

          <select
            value={selectedQuizId}
            onChange={(e) => setSelectedQuizId(e.target.value)}
            className="select-field"
            required
          >
            <option value="">Select Quiz</option>
            {quizzes.length > 0 && quizzes.map((quiz) => (
              <option key={quiz.id} value={quiz.id}>
                {quiz.title}
              </option>
            ))}
          </select>

          <button type="submit" className="submit-button">Assign Quiz</button>
        </form>
      </section>

      <section className="quiz-question-section">
        <h3 className="section-title">View/Add Questions to Quiz</h3>
        <select
          value={selectedQuizId}
          onChange={(e) => {
            setSelectedQuizId(e.target.value);
            if (e.target.value) {
              fetchQuizDetails(e.target.value);
            }
          }}
          className="select-field"
          required
        >
          <option value="">Select Quiz</option>
          {quizzes.length > 0 && quizzes.map((quiz) => (
            <option key={quiz.id} value={quiz.id}>
              {quiz.title}
            </option>
          ))}
        </select>

        {quizDetails && (
          <div className="quiz-details">
            <h4 className="quiz-title">Title: {quizDetails.title}</h4>
            <p className="quiz-description">Description: {quizDetails.description}</p>
            <h4 className="questions-title">Questions:</h4>
            <ul className="list-group">
              {quizDetails.questions.length > 0 ? (
                quizDetails.questions.map((question) => (
                  <li key={question.id} className="list-item">{question.question_text}</li>
                ))
              ) : (
                <li className="list-item">No questions found</li>
              )}
            </ul>

            <h4 className="section-title">Add Question to Quiz</h4>
            <form className="add-question-form" onSubmit={(e) => {
              e.preventDefault();
              handleAddQuestion(selectedQuizId);
            }}>
              <input
                type="text"
                placeholder="Question Text"
                value={questionText}
                className="input-field"
                onChange={(e) => setQuestionText(e.target.value)}
                required
              />
              <input
                type="text"
                placeholder="Correct Answer"
                value={correctAnswer}
                className="input-field"
                onChange={(e) => setCorrectAnswer(e.target.value)}
                required
              />
              {options.map((option, index) => (
                <input
                  key={index}
                  type="text"
                  placeholder={`Option ${index + 1}`}
                  value={option}
                  className="input-field"
                  onChange={(e) => handleOptionChange(index, e.target.value)}
                />
              ))}
              <button type="button" className="add-option-button" onClick={() => setOptions([...options, ''])}>Add Option</button>
              <button type="submit" className="submit-button">Add Question</button>
            </form>
          </div>
        )}
      </section>
    </div>
    </div>
  );
};

export default AdminDashboard;