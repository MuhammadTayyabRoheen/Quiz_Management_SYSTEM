import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';
import '../styles/StudentList.css';

const ManagerStudentList = () => {
  const [students, setStudents] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const response = await api.get('/manager/students');
      setStudents(response.data.data || []);
    } catch (error) {
      setErrorMessage('Failed to fetch students.');
    }
  };

  return (
    <div className="student-list-container">
      <h2 className="dashboard-title">Manager Student List</h2>
      {errorMessage && <div className="error-message">{errorMessage}</div>}

      {/* Student Table */}
      <div className="student-table-wrapper">
        <table className="student-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <tr key={student.id}>
                <td>{student.name}</td>
                <td>{student.email}</td>
                <td>{student.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
       
      {/* Back to Manager Dashboard Button */}
      <button onClick={() => navigate('/manager-dashboard')} className="back-button">
        Back to Manager Dashboard
      </button>
      {/* Additional Content */}
      <div className="student-section">
        <h3 className="section-title">Manage Submissions</h3>
        <a href="/manager/view-submissions" className="link">View Student Submissions</a>
      </div>
    </div>
  );
};

export default ManagerStudentList;
